# GokerBot website starter

This is a static, responsive landing-page starter for the GokerBot brand.

## Preview locally
Open `index.html` in a browser.

## Publish it for a public link
1. Create an account at https://vercel.com/
2. Import this folder as a new project (or upload the files using a supported deployment workflow).
3. Deploy. Vercel will assign a public `*.vercel.app` URL.
4. To use a custom domain, buy a domain and connect it in Vercel project settings.

## Important
This is the public-facing frontend only. The dashboard preview uses sample numbers; login, customer database, payments, license validation, and any game-client automation are not implemented. Add a secure backend before accepting customers or payments. Use only integrations and automation permitted by the game publisher's terms.
